#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  NEURO//TERM — терминальный чат-бот с памятью диалогов
================================================================================

  Что умеет:
    • Общается с вашей нейросетью через API (OpenAI-совместимый формат
      /v1/chat/completions — подходит для OpenAI, Ollama, LM Studio,
      vLLM, llama.cpp server и большинства self-hosted моделей).
    • Помнит контекст текущего диалога (вся история отправляется в модель).
    • Хранит ВСЕ диалоги в локальной базе SQLite (chat_memory.db) —
      история не теряется между запусками.
    • Команды управления: /new /list /load /rename /delete /history /clear.

  Зависимости: ТОЛЬКО стандартная библиотека Python 3.8+ (ничего ставить
  не нужно). Запуск:  python chatbot.py

  Настройка своей нейросети — через переменные окружения
  (или прямо в секции CONFIG ниже):

    NEURO_API_URL   — endpoint chat completions.
                      Примеры:
                        OpenAI     : https://api.openai.com/v1/chat/completions
                        Ollama     : http://localhost:11434/v1/chat/completions
                        LM Studio  : http://localhost:1234/v1/chat/completions
    NEURO_API_KEY   — ключ API (для локальных моделей можно любой, напр. "local")
    NEURO_MODEL     — имя модели, напр. "gpt-4o-mini" или "llama3.1:8b"
    NEURO_SYSTEM    — системный промпт (роль бота)
    NEURO_DB        — путь к файлу базы памяти (по умолчанию chat_memory.db)
================================================================================
"""

import json
import os
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime

# ---------------------------------------------------------------------------
# CONFIG — при желании впишите значения прямо сюда вместо переменных окружения
# ---------------------------------------------------------------------------
API_URL = os.getenv("NEURO_API_URL", "http://localhost:11434/v1/chat/completions")
API_KEY = os.getenv("NEURO_API_KEY", "local")
MODEL = os.getenv("NEURO_MODEL", "llama3.1:8b")
SYSTEM_PROMPT = os.getenv(
    "NEURO_SYSTEM",
    "Ты — полезный ассистент. Отвечай по-русски, кратко и по существу.",
)
DB_PATH = os.getenv("NEURO_DB", "chat_memory.db")

MAX_CONTEXT_MESSAGES = 40   # сколько последних сообщений отправлять модели (память)
REQUEST_TIMEOUT = 120       # сек. ожидания ответа API
TEMPERATURE = 0.7

# ---------------------------------------------------------------------------
# UI: ANSI-цвета и утилиты вывода
# ---------------------------------------------------------------------------
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
GREEN = "\033[92m"
AMBER = "\033[93m"
CYAN = "\033[96m"
RED = "\033[91m"
GRAY = "\033[90m"


def c(text: str, color: str) -> str:
    """Окрашивает текст, если вывод в терминал."""
    if not sys.stdout.isatty():
        return text
    return f"{color}{text}{RESET}"


def print_assistant(text: str) -> None:
    """Печатает ответ модели с эффектом 'печати'."""
    prefix = c("neuro", GREEN) + c(" › ", DIM)
    sys.stdout.write("\n" + prefix)
    sys.stdout.flush()
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(0.004)
    sys.stdout.write("\n\n")


def print_info(text: str) -> None:
    print(c("  · " + text, GRAY))


def print_error(text: str) -> None:
    print(c("  ✗ " + text, RED))


class Spinner:
    """Анимация ожидания ответа, пока идёт запрос к API."""

    FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, label: str = "думаю"):
        self._stop = threading.Event()
        prefix = c("neuro", GREEN) + c(" › ", DIM)
        self._thread = threading.Thread(target=self._run, args=(prefix, label), daemon=True)

    def _run(self, prefix: str, label: str) -> None:
        i = 0
        while not self._stop.is_set():
            frame = c(self.FRAMES[i % len(self.FRAMES)], CYAN)
            sys.stdout.write(f"\r{prefix}{frame} {c(label + '...', GRAY)}")
            sys.stdout.flush()
            i += 1
            time.sleep(0.08)

    def __enter__(self) -> "Spinner":
        self._thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self._stop.set()
        self._thread.join()
        sys.stdout.write("\r" + " " * 40 + "\r")
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# MEMORY: хранилище диалогов в SQLite
# ---------------------------------------------------------------------------
class Memory:
    """Постоянная память бота: диалоги + сообщения, переживает перезапуск."""

    def __init__(self, path: str) -> None:
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS conversations (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                title      TEXT NOT NULL DEFAULT 'Новый диалог',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS messages (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER NOT NULL REFERENCES conversations(id)
                                ON DELETE CASCADE,
                role            TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
                content         TEXT NOT NULL,
                created_at      TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_messages_conv
                ON messages(conversation_id, id);
            """
        )
        self.conn.commit()

    @staticmethod
    def _now() -> str:
        return datetime.now().isoformat(timespec="seconds")

    # --- диалоги -----------------------------------------------------------
    def create_conversation(self, title: str = "Новый диалог") -> int:
        now = self._now()
        cur = self.conn.execute(
            "INSERT INTO conversations (title, created_at, updated_at) VALUES (?,?,?)",
            (title, now, now),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def list_conversations(self) -> list:
        return self.conn.execute(
            """
            SELECT c.id, c.title, c.updated_at,
                   (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id) AS msg_count
            FROM conversations c
            ORDER BY c.updated_at DESC
            """
        ).fetchall()

    def rename_conversation(self, conv_id: int, title: str) -> None:
        self.conn.execute(
            "UPDATE conversations SET title=? WHERE id=?", (title, conv_id)
        )
        self.conn.commit()

    def delete_conversation(self, conv_id: int) -> None:
        self.conn.execute("DELETE FROM messages WHERE conversation_id=?", (conv_id,))
        self.conn.execute("DELETE FROM conversations WHERE id=?", (conv_id,))
        self.conn.commit()

    def conversation_exists(self, conv_id: int) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM conversations WHERE id=?", (conv_id,)
        ).fetchone()
        return row is not None

    # --- сообщения ---------------------------------------------------------
    def add_message(self, conv_id: int, role: str, content: str) -> None:
        now = self._now()
        self.conn.execute(
            "INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?,?,?,?)",
            (conv_id, role, content, now),
        )
        self.conn.execute(
            "UPDATE conversations SET updated_at=? WHERE id=?", (now, conv_id)
        )
        self.conn.commit()

    def get_messages(self, conv_id: int, limit: int | None = None) -> list:
        """История диалога. limit — последние N сообщений (для контекста)."""
        rows = self.conn.execute(
            "SELECT role, content FROM messages WHERE conversation_id=? ORDER BY id",
            (conv_id,),
        ).fetchall()
        if limit:
            rows = rows[-limit:]
        return [{"role": r["role"], "content": r["content"]} for r in rows]

    def close(self) -> None:
        self.conn.close()


# ---------------------------------------------------------------------------
# API: клиент нейросети (OpenAI-совместимый /chat/completions)
# ---------------------------------------------------------------------------
class NeuroClient:
    """Отправляет историю диалога в модель и возвращает ответ."""

    def __init__(self, url: str, key: str, model: str) -> None:
        self.url = url
        self.key = key
        self.model = model

    def chat(self, history: list) -> str:
        """history: [{'role': ..., 'content': ...}, ...] — память диалога."""
        payload = {
            "model": self.model,
            "messages": history,
            "temperature": TEMPERATURE,
            "max_tokens": 2048,
            "stream": False,
        }
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            self.url,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.key}",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:300]
            raise RuntimeError(f"API вернул HTTP {e.code}: {detail}") from e
        except urllib.error.URLError as e:
            raise RuntimeError(
                f"Не могу подключиться к {self.url} ({e.reason}). "
                f"Проверьте, что ваша нейросеть запущена и NEURO_API_URL верный."
            ) from e
        except json.JSONDecodeError as e:
            raise RuntimeError("API вернул не-JSON ответ. Проверьте endpoint.") from e

        try:
            return data["choices"][0]["message"]["content"].strip()
        except (KeyError, IndexError, TypeError) as e:
            raise RuntimeError(
                f"Неожиданный формат ответа API: {json.dumps(data, ensure_ascii=False)[:300]}"
            ) from e


# ---------------------------------------------------------------------------
# BOT: собираем всё вместе
# ---------------------------------------------------------------------------
HELP = f"""
{c('КОМАНДЫ', BOLD)}
  {c('/help', CYAN)}           — эта справка
  {c('/new [название]', CYAN)} — начать новый диалог
  {c('/list', CYAN)}           — список сохранённых диалогов
  {c('/load N', CYAN)}         — продолжить диалог №N (память подгрузится)
  {c('/rename ТЕКСТ', CYAN)}   — переименовать текущий диалог
  {c('/delete N', CYAN)}       — удалить диалог №N
  {c('/history [N]', CYAN)}    — показать последние N сообщений (по умолч. 10)
  {c('/model ИМЯ', CYAN)}      — сменить модель на лету
  {c('/clear', CYAN)}          — очистить экран
  {c('/exit', CYAN)}           — выход
"""


class ChatBot:
    def __init__(self) -> None:
        self.memory = Memory(DB_PATH)
        self.client = NeuroClient(API_URL, API_KEY, MODEL)
        self.conv_id: int | None = None

    # --- запуск ------------------------------------------------------------
    def run(self) -> None:
        self._banner()
        # Продолжаем самый свежий диалог, либо создаём новый
        convs = self.memory.list_conversations()
        if convs:
            self.conv_id = int(convs[0]["id"])
            print_info(
                f"Продолжаем диалог №{self.conv_id} «{convs[0]['title']}» "
                f"(память: {convs[0]['msg_count']} сообщ.). /new — новый диалог."
            )
        else:
            self.conv_id = self.memory.create_conversation()
            print_info("Создан первый диалог. Просто пишите сообщение.")

        while True:
            try:
                raw = input(c("вы", AMBER) + c("    › ", DIM)).strip()
            except (EOFError, KeyboardInterrupt):
                print()
                self._bye()
                break
            if not raw:
                continue
            if raw.startswith("/"):
                if not self._command(raw):
                    break
                continue
            self._ask(raw)

        self.memory.close()

    # --- main loop ----------------------------------------------------------
    def _ask(self, text: str) -> None:
        assert self.conv_id is not None
        # Если это первое сообщение диалога — используем его как название
        self._maybe_autotitle(text)
        # 1) сохраняем сообщение пользователя в память
        self.memory.add_message(self.conv_id, "user", text)
        # 2) собираем контекст: системный промпт + последние N сообщений
        history = [{"role": "system", "content": SYSTEM_PROMPT}]
        history += self.memory.get_messages(self.conv_id, limit=MAX_CONTEXT_MESSAGES)
        # 3) спрашиваем нейросеть
        try:
            with Spinner():
                reply = self.client.chat(history)
        except RuntimeError as e:
            print_error(str(e))
            return
        # 4) сохраняем ответ и печатаем
        self.memory.add_message(self.conv_id, "assistant", reply)
        print_assistant(reply)

    def _maybe_autotitle(self, text: str) -> None:
        assert self.conv_id is not None
        if len(self.memory.get_messages(self.conv_id)) == 0:
            title = text if len(text) <= 42 else text[:41] + "…"
            self.memory.rename_conversation(self.conv_id, title)

    # --- команды ------------------------------------------------------------
    def _command(self, raw: str) -> bool:
        """Обработка /команд. Возвращает False, если нужно выйти."""
        parts = raw.split(maxsplit=1)
        cmd, arg = parts[0].lower(), (parts[1].strip() if len(parts) > 1 else "")

        if cmd in ("/exit", "/quit", "/q"):
            self._bye()
            return False
        if cmd == "/help":
            print(HELP)
        elif cmd == "/new":
            title = arg or "Новый диалог"
            self.conv_id = self.memory.create_conversation(title)
            print_info(f"Новый диалог №{self.conv_id} «{title}». Память чиста.")
        elif cmd == "/list":
            self._list()
        elif cmd == "/load":
            self._load(arg)
        elif cmd == "/rename":
            if not arg:
                print_error("Укажите название: /rename Текст")
            else:
                self.memory.rename_conversation(self.conv_id, arg)
                print_info(f"Диалог переименован в «{arg}».")
        elif cmd == "/delete":
            self._delete(arg)
        elif cmd == "/history":
            limit = int(arg) if arg.isdigit() else 10
            self._history(limit)
        elif cmd == "/model":
            if not arg:
                print_info(f"Текущая модель: {self.client.model}")
            else:
                self.client.model = arg
                print_info(f"Модель переключена на «{arg}».")
        elif cmd == "/clear":
            os.system("cls" if os.name == "nt" else "clear")
            self._banner()
        else:
            print_error(f"Неизвестная команда «{cmd}». /help — справка.")
        return True

    def _list(self) -> None:
        convs = self.memory.list_conversations()
        if not convs:
            print_info("Сохранённых диалогов нет.")
            return
        print(c("\n  СОХРАНЁННЫЕ ДИАЛОГИ", BOLD))
        for r in convs:
            mark = c("●", GREEN) if r["id"] == self.conv_id else c("○", GRAY)
            ts = r["updated_at"].replace("T", " ")
            num = c(f"№{r['id']:>4}", CYAN)
            count = c(f"{r['msg_count']:>3} сообщ.", GRAY)
            print(f"  {mark} {num}  {r['title'][:40]:<40} {count} {c(ts, DIM)}")
        print()

    def _load(self, arg: str) -> None:
        if not arg.isdigit():
            print_error("Укажите номер: /load N (номера — в /list)")
            return
        conv_id = int(arg)
        if not self.memory.conversation_exists(conv_id):
            print_error(f"Диалог №{conv_id} не найден.")
            return
        self.conv_id = conv_id
        n = len(self.memory.get_messages(conv_id))
        print_info(f"Диалог №{conv_id} загружен. Память: {n} сообщений — модель их помнит.")
        self._history(4)

    def _delete(self, arg: str) -> None:
        if not arg.isdigit():
            print_error("Укажите номер: /delete N")
            return
        conv_id = int(arg)
        if not self.memory.conversation_exists(conv_id):
            print_error(f"Диалог №{conv_id} не найден.")
            return
        self.memory.delete_conversation(conv_id)
        print_info(f"Диалог №{conv_id} удалён.")
        if conv_id == self.conv_id:
            convs = self.memory.list_conversations()
            self.conv_id = (
                int(convs[0]["id"]) if convs else self.memory.create_conversation()
            )
            print_info(f"Переключился на диалог №{self.conv_id}.")

    def _history(self, limit: int) -> None:
        msgs = self.memory.get_messages(self.conv_id, limit=limit)
        if not msgs:
            print_info("В этом диалоге пока нет сообщений.")
            return
        print(c(f"\n  ПОСЛЕДНИЕ {len(msgs)} СООБЩЕНИЙ", BOLD))
        for m in msgs:
            who = c("вы   ", AMBER) if m["role"] == "user" else c("neuro", GREEN)
            snippet = m["content"].replace("\n", " ")[:90]
            print(f"  {who} {c('›', DIM)} {snippet}")
        print()

    # --- прочее -------------------------------------------------------------
    def _banner(self) -> None:
        print(
            c(
                r"""
  ╔══════════════════════════════════════════════════════╗
  ║   ███╗   ██╗███████╗██╗   ██╗██████╗  ██████╗        ║
  ║   ████╗  ██║██╔════╝██║   ██║██╔══██╗██╔═══██╗       ║
  ║   ██╔██╗ ██║█████╗  ██║   ██║██████╔╝██║   ██║       ║
  ║   ██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██║   ██║       ║
  ║   ██║ ╚████║███████╗╚██████╔╝██║  ██║╚██████╔╝       ║
  ║   ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ TERM   ║
  ╚══════════════════════════════════════════════════════╝""",
                GREEN,
            )
        )
        print(c(f"  модель: {self.client.model}  ·  endpoint: {self.client.url}", GRAY))
        print(c(f"  память: {DB_PATH}  ·  контекст: последние {MAX_CONTEXT_MESSAGES} сообщ.", GRAY))
        print(c("  /help — команды, /exit — выход\n", GRAY))

    @staticmethod
    def _bye() -> None:
        print(c("  Сеанс завершён. История сохранена в памяти. Пока!\n", GREEN))


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    try:
        ChatBot().run()
    except sqlite3.Error as e:
        print_error(f"Ошибка базы памяти: {e}")
        sys.exit(1)
