import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import { NextResponse } from "next/server";

/** Список диалогов (с количеством сообщений), свежие сверху. */
export async function GET() {
  const rows = await db
    .select({
      id: conversations.id,
      title: conversations.title,
      createdAt: conversations.createdAt,
      updatedAt: conversations.updatedAt,
      messageCount: sql<number>`(
        select count(*)::int from ${messages}
        where ${messages.conversationId} = ${conversations.id}
      )`,
    })
    .from(conversations)
    .orderBy(desc(conversations.updatedAt))
    .limit(200);

  return NextResponse.json(rows);
}

/** Создать новый диалог. */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { title?: string };
  const title =
    typeof body.title === "string" && body.title.trim()
      ? body.title.trim().slice(0, 120)
      : "Новый диалог";

  const [row] = await db.insert(conversations).values({ title }).returning();
  return NextResponse.json({ ...row, messageCount: 0 }, { status: 201 });
}
