import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type RouteCtx = { params: Promise<{ id: string }> };

/** Диалог + вся его история (память). */
export async function GET(_req: Request, { params }: RouteCtx) {
  const { id } = await params;

  const [conv] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, id))
    .limit(1);

  if (!conv) {
    return NextResponse.json({ error: "Диалог не найден" }, { status: 404 });
  }

  const history = await db
    .select({
      id: messages.id,
      role: messages.role,
      content: messages.content,
      createdAt: messages.createdAt,
    })
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(asc(messages.seq));

  return NextResponse.json({ ...conv, messages: history });
}

/** Переименовать диалог. */
export async function PATCH(req: Request, { params }: RouteCtx) {
  const { id } = await params;
  const body = (await req.json().catch(() => ({}))) as { title?: string };
  const title = typeof body.title === "string" ? body.title.trim() : "";

  if (!title) {
    return NextResponse.json({ error: "Пустое название" }, { status: 400 });
  }

  const [row] = await db
    .update(conversations)
    .set({ title: title.slice(0, 120), updatedAt: new Date() })
    .where(eq(conversations.id, id))
    .returning();

  if (!row) {
    return NextResponse.json({ error: "Диалог не найден" }, { status: 404 });
  }
  return NextResponse.json(row);
}

/** Удалить диалог вместе с историей (каскад). */
export async function DELETE(_req: Request, { params }: RouteCtx) {
  const { id } = await params;
  const [row] = await db
    .delete(conversations)
    .where(eq(conversations.id, id))
    .returning({ id: conversations.id });

  if (!row) {
    return NextResponse.json({ error: "Диалог не найден" }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}
