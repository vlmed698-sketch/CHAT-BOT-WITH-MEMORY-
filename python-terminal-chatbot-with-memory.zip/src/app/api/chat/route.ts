import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { streamChat, systemMessage, type ChatMessage } from "@/lib/ai";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

const MAX_CONTEXT_MESSAGES = 40;

/**
 * POST /api/chat
 * Тело: { conversationId: string, content: string }
 *
 * 1. Сохраняет сообщение пользователя в память (PostgreSQL).
 * 2. Собирает контекст: system-промпт + последние N сообщений диалога.
 * 3. Стримит ответ нейросети (токены, text/plain).
 * 4. По завершении стрима сохраняет ответ ассистента в память.
 */
export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    conversationId?: string;
    content?: string;
  };
  const conversationId = body.conversationId;
  const content = typeof body.content === "string" ? body.content.trim() : "";

  if (!conversationId || !content) {
    return NextResponse.json(
      { error: "Нужны conversationId и content" },
      { status: 400 },
    );
  }

  const [conv] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId))
    .limit(1);

  if (!conv) {
    return NextResponse.json({ error: "Диалог не найден" }, { status: 404 });
  }

  // Память: сообщение пользователя
  await db.insert(messages).values({ conversationId, role: "user", content });

  // Автоназвание из первого сообщения + актуализация updatedAt
  const patch: { updatedAt: Date; title?: string } = { updatedAt: new Date() };
  if (conv.title === "Новый диалог") {
    const flat = content.replace(/\s+/g, " ");
    patch.title = flat.length > 48 ? flat.slice(0, 47) + "…" : flat;
  }
  await db
    .update(conversations)
    .set(patch)
    .where(eq(conversations.id, conversationId));

  // Контекст для модели — последние N сообщений + системный промпт
  const recent = await db
    .select({ role: messages.role, content: messages.content })
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(desc(messages.seq))
    .limit(MAX_CONTEXT_MESSAGES);
  recent.reverse();

  const history: ChatMessage[] = [systemMessage(), ...recent];
  const source = streamChat(history);

  const encoder = new TextEncoder();
  let fullText = "";

  const persist = async (text: string) => {
    if (!text.trim()) return;
    try {
      await db
        .insert(messages)
        .values({ conversationId, role: "assistant", content: text });
      await db
        .update(conversations)
        .set({ updatedAt: new Date() })
        .where(eq(conversations.id, conversationId));
    } catch (e) {
      console.error("Не удалось сохранить ответ ассистента:", e);
    }
  };

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const reader = source.getReader();
      try {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          fullText += value;
          controller.enqueue(encoder.encode(value));
        }
      } finally {
        controller.close();
        await persist(fullText);
      }
    },
    async cancel() {
      // Клиент остановил генерацию — сохраняем накопленное
      try {
        await source.cancel();
      } catch {
        /* noop */
      }
      await persist(fullText);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
