import type { Metadata } from "next";
import type { ReactNode } from "react";
import { JetBrains_Mono, Unbounded } from "next/font/google";
import "./globals.css";

const jbMono = JetBrains_Mono({
  subsets: ["latin", "cyrillic"],
  variable: "--font-jbm",
  display: "swap",
});

const unbounded = Unbounded({
  subsets: ["latin", "cyrillic"],
  variable: "--font-unbounded",
  display: "swap",
});

export const metadata: Metadata = {
  title: "НЕЙРО//ЧАТ — терминал с памятью",
  description:
    "Чат-бот с памятью диалогов. Подключите свою нейросеть через API — история хранится в PostgreSQL.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${jbMono.variable} ${unbounded.variable}`}>
      <body className="bg-void font-mono text-ink antialiased">{children}</body>
    </html>
  );
}
