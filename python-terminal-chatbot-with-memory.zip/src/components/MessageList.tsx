"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { CornerDownRight } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { formatTimeShort } from "./format";
import type { UiMessage } from "./types";

interface MessageListProps {
  messages: UiMessage[];
  streaming: boolean;
  streamText: string;
  model: string;
  onSuggest: (text: string) => void;
}

const SUGGESTIONS = [
  "Объясни, как у тебя устроена память диалогов",
  "Напиши скрипт-сортировку на Python одной строкой",
  "Составь план изучения Rust на 30 дней",
  "Придумай 5 названий для стартапа в сфере ИИ",
];

function Markdown({ text }: { text: string }) {
  return (
    <div className="md">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: (props) => <a {...props} target="_blank" rel="noreferrer" />,
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
}

export default function MessageList({
  messages,
  streaming,
  streamText,
  model,
  onSuggest,
}: MessageListProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, streamText, streaming]);

  const isEmpty = messages.length === 0 && !streaming && !streamText;

  return (
    <div ref={scrollRef} className="relative min-h-0 flex-1 overflow-y-auto">
      {isEmpty ? (
        /* ---------------- ПУСТОЕ СОСТОЯНИЕ ---------------- */
        <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col items-center justify-center px-5 py-14">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="flex w-full flex-col items-center text-center"
          >
            <div className="text-[11px] tracking-[0.3em] text-fog">
              ~/neuro-chat — сессия открыта
            </div>

            <h1 className="mt-5 font-display text-[clamp(26px,5vw,46px)] font-black leading-[1.08] tracking-tight text-white">
              ЗАДАЙТЕ ВОПРОС
              <span className="ml-2 inline-block h-[0.85em] w-[0.5em] translate-y-[0.08em] animate-blink bg-phosphor shadow-[0_0_18px_rgba(92,255,157,0.7)]" />
            </h1>

            <p className="mt-4 max-w-md text-[12.5px] leading-relaxed text-fog">
              Каждый диалог сохраняется в PostgreSQL. Модель получает контекст
              последних 40 сообщений — она помнит, о чём вы говорили.
            </p>

            <div className="mt-9 grid w-full max-w-xl grid-cols-1 gap-2 sm:grid-cols-2">
              {SUGGESTIONS.map((s, i) => (
                <motion.button
                  key={s}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.35 + i * 0.07, duration: 0.4 }}
                  onClick={() => onSuggest(s)}
                  className="group flex items-start gap-2 rounded-xl border border-edge bg-panel/70 px-4 py-3 text-left text-[12px] leading-snug text-fog transition hover:border-phosphor/40 hover:bg-panel2 hover:text-ink"
                >
                  <CornerDownRight
                    size={13}
                    className="mt-0.5 shrink-0 text-phosphor-dim transition group-hover:text-phosphor"
                  />
                  {s}
                </motion.button>
              ))}
            </div>

            <div className="mt-9 text-[10px] uppercase tracking-[0.25em] text-fog/70">
              модель: <span className="text-phosphor-dim">{model}</span>
            </div>
          </motion.div>
        </div>
      ) : (
        /* ---------------- ЛЕНТА СООБЩЕНИЙ ---------------- */
        <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6">
          <div className="space-y-7">
            {messages.map((m) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                className={m.role === "user" ? "flex justify-end" : "flex"}
              >
                {m.role === "user" ? (
                  <div className="max-w-[85%] sm:max-w-[75%]">
                    <div className="mb-1.5 flex items-baseline justify-end gap-2">
                      <span className="text-[10px] text-fog/70">
                        {formatTimeShort(m.createdAt)}
                      </span>
                      <span className="text-[11px] font-semibold tracking-wide text-ambera">
                        вы
                      </span>
                    </div>
                    <div className="whitespace-pre-wrap rounded-2xl rounded-tr-md border border-ambera/25 bg-ambera/[0.06] px-4 py-3 text-[13.5px] leading-relaxed text-[#f3e9d8]">
                      {m.content}
                    </div>
                  </div>
                ) : (
                  <div className="max-w-[92%] sm:max-w-[85%]">
                    <div className="mb-1.5 flex items-baseline gap-2">
                      <span className="flex items-center gap-1.5 text-[11px] font-semibold tracking-wide text-phosphor">
                        <span className="inline-block h-1.5 w-1.5 rounded-[2px] bg-phosphor shadow-[0_0_6px_rgba(92,255,157,0.8)]" />
                        neuro
                      </span>
                      <span className="text-[10px] text-fog/70">
                        {formatTimeShort(m.createdAt)}
                      </span>
                    </div>
                    <div className="rounded-2xl rounded-tl-md border border-edge bg-panel/80 px-4 py-3">
                      <Markdown text={m.content} />
                    </div>
                  </div>
                )}
              </motion.div>
            ))}

            {/* стримящийся ответ */}
            {streaming && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex"
              >
                <div className="max-w-[92%] sm:max-w-[85%]">
                  <div className="mb-1.5 flex items-baseline gap-2">
                    <span className="flex items-center gap-1.5 text-[11px] font-semibold tracking-wide text-phosphor">
                      <span className="inline-block h-1.5 w-1.5 animate-blink rounded-[2px] bg-phosphor" />
                      neuro
                    </span>
                    <span className="text-[10px] uppercase tracking-widest text-fog/70">
                      печатает…
                    </span>
                  </div>
                  <div className="rounded-2xl rounded-tl-md border border-phosphor/20 bg-panel/80 px-4 py-3">
                    {streamText ? (
                      <>
                        <Markdown text={streamText} />
                        <span className="stream-cursor" />
                      </>
                    ) : (
                      <span className="flex items-center gap-1.5 py-1">
                        {[0, 1, 2].map((i) => (
                          <span
                            key={i}
                            className="h-1.5 w-1.5 animate-bounce rounded-full bg-phosphor/70"
                            style={{ animationDelay: `${i * 160}ms` }}
                          />
                        ))}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </div>
          <div className="h-6" />
        </div>
      )}
    </div>
  );
}
