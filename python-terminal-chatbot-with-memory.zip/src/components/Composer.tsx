"use client";

import { useEffect, useRef } from "react";
import { ArrowUp, Square } from "lucide-react";

interface ComposerProps {
  value: string;
  streaming: boolean;
  onChange: (v: string) => void;
  onSend: () => void;
  onStop: () => void;
}

export default function Composer({
  value,
  streaming,
  onChange,
  onSend,
  onStop,
}: ComposerProps) {
  const taRef = useRef<HTMLTextAreaElement>(null);

  // автовысота
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "0px";
    ta.style.height = Math.min(ta.scrollHeight, 180) + "px";
  }, [value]);

  const canSend = value.trim().length > 0 && !streaming;

  return (
    <div className="relative shrink-0 px-4 pb-4 pt-2 sm:px-6 sm:pb-6">
      <div className="mx-auto w-full max-w-3xl">
        <div className="rounded-2xl border border-edge bg-panel shadow-[0_-12px_40px_rgba(0,0,0,0.35)] transition focus-within:border-phosphor/45 focus-within:shadow-[0_0_0_1px_rgba(92,255,157,0.12),0_-12px_40px_rgba(0,0,0,0.35)]">
          <textarea
            id="composer-input"
            ref={taRef}
            value={value}
            rows={1}
            autoFocus
            placeholder="сообщение нейросети…"
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                if (canSend) onSend();
              }
            }}
            className="block max-h-[180px] w-full resize-none bg-transparent px-4 pb-1 pt-4 text-[13.5px] leading-relaxed text-ink placeholder:text-fog/50 focus:outline-none"
          />

          <div className="flex items-end justify-between gap-3 px-3 pb-3 pt-1">
            <div className="hidden items-center gap-2 text-[10px] text-fog/70 sm:flex">
              <span className="kbd">enter</span>
              <span>отправить</span>
              <span className="text-edge2">·</span>
              <span className="kbd">shift + enter</span>
              <span>новая строка</span>
            </div>
            <div className="flex items-center sm:hidden" />

            <div className="flex items-center gap-3">
              {value.length > 0 && (
                <span className="text-[10px] tabular-nums text-fog/60">
                  {value.length}
                </span>
              )}
              {streaming ? (
                <button
                  onClick={onStop}
                  title="Остановить генерацию"
                  className="flex h-9 w-9 items-center justify-center rounded-xl border border-ambera/50 bg-ambera/10 text-ambera transition hover:bg-ambera/20"
                >
                  <Square size={13} fill="currentColor" />
                </button>
              ) : (
                <button
                  onClick={onSend}
                  disabled={!canSend}
                  title="Отправить"
                  className={`flex h-9 w-9 items-center justify-center rounded-xl transition ${
                    canSend
                      ? "bg-phosphor text-black shadow-[0_0_18px_rgba(92,255,157,0.35)] hover:bg-[#7dffae]"
                      : "cursor-not-allowed border border-edge bg-panel2 text-fog/50"
                  }`}
                >
                  <ArrowUp size={16} strokeWidth={2.5} />
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="mt-2 text-center text-[9.5px] uppercase tracking-[0.2em] text-fog/50">
          нейросеть может ошибаться · история хранится локально в вашей бд
        </div>
      </div>
    </div>
  );
}
