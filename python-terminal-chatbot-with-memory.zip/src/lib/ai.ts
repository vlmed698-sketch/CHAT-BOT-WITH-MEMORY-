/**
 * Серверный клиент нейросети (OpenAI-совместимый /chat/completions).
 *
 * Переменные окружения:
 *   AI_API_URL  — endpoint, напр. http://localhost:11434/v1/chat/completions
 *   AI_API_KEY  — ключ (для локальных моделей — любая строка)
 *   AI_MODEL    — имя модели
 *   AI_SYSTEM   — системный промпт
 *
 * Если AI_API_URL не задан — работает демо-режим (локальный ответчик),
 * чтобы интерфейс был живым до подключения настоящей модели.
 */

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

const API_URL = process.env.AI_API_URL ?? "";
const API_KEY = process.env.AI_API_KEY ?? "local";
const MODEL = process.env.AI_MODEL ?? "demo-local";
const SYSTEM_PROMPT =
  process.env.AI_SYSTEM ??
  "Ты — полезный ассистент. Отвечай по-русски, кратко и по существу.";

export function aiConfig() {
  return {
    configured: Boolean(API_URL),
    model: API_URL ? MODEL : "demo-local",
    systemPrompt: SYSTEM_PROMPT,
  };
}

export function systemMessage(): ChatMessage {
  return { role: "system", content: SYSTEM_PROMPT };
}

/**
 * Возвращает ReadableStream<string> с токенами ответа модели.
 * Используется API-роутом /api/chat для потоковой отдачи в браузер.
 */
export function streamChat(history: ChatMessage[]): ReadableStream<string> {
  if (!API_URL) return demoStream(history);
  return remoteStream(history);
}

/* ------------------------------------------------------------------ */
/* Реальный API (SSE-стриминг OpenAI-формата)                          */
/* ------------------------------------------------------------------ */

function remoteStream(history: ChatMessage[]): ReadableStream<string> {
  return new ReadableStream<string>({
    async start(controller) {
      let response: Response;
      try {
        response = await fetch(API_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${API_KEY}`,
          },
          body: JSON.stringify({
            model: MODEL,
            messages: history,
            temperature: 0.7,
            stream: true,
          }),
        });
      } catch {
        controller.enqueue(
          `[ошибка] Не могу подключиться к ${API_URL}. Проверьте, что нейросеть запущена.`,
        );
        controller.close();
        return;
      }

      if (!response.ok || !response.body) {
        const detail = (await response.text().catch(() => "")).slice(0, 300);
        controller.enqueue(
          `[ошибка] API вернул HTTP ${response.status}. ${detail}`,
        );
        controller.close();
        return;
      }

      const contentType = response.headers.get("content-type") ?? "";
      if (!contentType.includes("text/event-stream")) {
        // Некоторые локальные серверы игнорируют stream:true — читаем как JSON
        const text = await response.text();
        try {
          const json = JSON.parse(text);
          const content =
            json?.choices?.[0]?.message?.content ??
            "Пустой ответ от модели.";
          controller.enqueue(String(content));
        } catch {
          controller.enqueue(text.slice(0, 4000));
        }
        controller.close();
        return;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const raw of lines) {
          const line = raw.trim();
          if (!line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (!data || data === "[DONE]") continue;
          try {
            const json = JSON.parse(data);
            const delta =
              json?.choices?.[0]?.delta?.content ??
              json?.choices?.[0]?.message?.content ??
              "";
            if (delta) controller.enqueue(String(delta));
          } catch {
            // неполный JSON-чанк — пропускаем
          }
        }
      }
      controller.close();
    },
  });
}

/* ------------------------------------------------------------------ */
/* Демо-режим: локальный генератор ответов с "печатью"                 */
/* ------------------------------------------------------------------ */

const DEMO_TEMPLATES: string[] = [
  "Принял: «{q}». Пока я работаю в демо-режиме — настоящая нейросеть ещё не подключена. Задайте переменные `AI_API_URL`, `AI_API_KEY` и `AI_MODEL` в файле `.env`, и я начну отвечать вашей моделью.\n\nКстати, я запомнил это сообщение: история диалога уже сохранена в PostgreSQL и будет отправляться в контексте при каждом следующем запросе.",
  "Записал в память. Ваше сообщение из {n} слов теперь часть контекста этого диалога. Подключите свою нейросеть (любой OpenAI-совместимый endpoint — Ollama, vLLM, LM Studio), и эти ответы заменит настоящая модель.\n\n```\nAI_API_URL=http://localhost:11434/v1/chat/completions\nAI_MODEL=llama3.1:8b\n```",
  "«{q}» — интересно. Я демо-ответчик, но пайплайн полностью боевой: сообщение → база → контекст → модель → стриминг ответа токен за токеном. Осталось указать `AI_API_URL`, и терминал оживёт вашей нейросетью.",
  "Вижу ваш запрос («{q}»). Демо-режим активен, потому что переменная `AI_API_URL` не задана. Все диалоги при этом сохраняются — см. сайдбар слева: там можно переключаться между ними, и каждый диалог помнит свой контекст.",
];

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

function demoReply(history: ChatMessage[]): string {
  const lastUser = [...history].reverse().find((m) => m.role === "user");
  const q = (lastUser?.content ?? "").replace(/\s+/g, " ").trim();
  const short = q.length > 80 ? q.slice(0, 79) + "…" : q;
  const words = q ? q.split(" ").length : 0;
  const tpl = DEMO_TEMPLATES[hashCode(q || String(Date.now())) % DEMO_TEMPLATES.length];
  return tpl.replaceAll("{q}", short).replaceAll("{n}", String(words));
}

function demoStream(history: ChatMessage[]): ReadableStream<string> {
  const text = demoReply(history);
  const chunks = text.split(/(?<=[ \n])/); // режем по словам, сохраняя пробелы
  let i = 0;
  let closed = false;
  let timer: ReturnType<typeof setTimeout> | undefined;

  return new ReadableStream<string>({
    pull(controller) {
      if (closed) return;
      return new Promise<void>((resolve) => {
        timer = setTimeout(() => {
          if (i < chunks.length) {
            controller.enqueue(chunks[i++]);
          } else {
            closed = true;
            controller.close();
          }
          resolve();
        }, 18);
      });
    },
    cancel() {
      closed = true;
      if (timer) clearTimeout(timer);
    },
  });
}
