#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
  NEURO//TERM — терминальный чат-бот с памятью диалогов
================================================================================

  Что умеет:
    • Общается с нейросетью через API:
        — GigaChat (Сбер): OAuth по ключу авторизации, авто-обновление
          токена (живёт 30 минут), потоковая печать ответа;
        — любой OpenAI-совместимый endpoint (/v1/chat/completions):
          OpenAI, Ollama, LM Studio, vLLM, llama.cpp server и т.д.
      Режим определяется автоматически: задан GIGACHAT_AUTH_KEY → GigaChat,
      иначе OpenAI-совместимый режим по NEURO_API_URL.
    • Помнит контекст текущего диалога (последние сообщения отправляются
      модели вместе с системным промптом).
    • Хранит ВСЕ диалоги в локальной базе SQLite (chat_memory.db) —
      история не теряется между запусками.
    • Команды: /new /list /load /rename /delete /history /model /clear.

  Зависимости: ТОЛЬКО стандартная библиотека Python 3.8+.

  ── Подключение GigaChat ──────────────────────────────────────────────
    1. developers.sber.ru → создайте проект GigaChat API →
       «Авторизационные данные» → скопируйте Ключ авторизации (Authorization Key).
    2. Задайте переменные окружения:
        export GIGACHAT_AUTH_KEY="MW..."
        export GIGACHAT_SCOPE="GIGACHAT_API_PERS"   # по умолчанию для физлиц
        export GIGACHAT_MODEL="GigaChat"            # GigaChat | -Pro | -Max ...
    3. Если при подключении ошибка TLS-сертификата (сертификат Минцифры
       отсутствует в системе), либо установите корневой сертификат,
       либо временно: export GIGACHAT_VERIFY_SSL=false

  ── Подключение OpenAI-совместимой нейросети ──────────────────────────
        export NEURO_API_URL="http://localhost:11434/v1/chat/completions"
        export NEURO_API_KEY="local"
        export NEURO_MODEL="llama3.1:8b"

  Общие переменные: NEURO_SYSTEM (промпт), NEURO_DB (файл памяти).
================================================================================
"""

import json
import os
import ssl
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime

# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------
# --- GigaChat (Сбер) ---
GIGACHAT_AUTH_KEY = os.getenv("GIGACHAT_AUTH_KEY", "")
GIGACHAT_SCOPE = os.getenv("GIGACHAT_SCOPE", "GIGACHAT_API_PERS")
GIGACHAT_MODEL = os.getenv("GIGACHAT_MODEL", "GigaChat")
GIGACHAT_API_URL = os.getenv(
    "GIGACHAT_API_URL", "https://gigachat.devices.sberbank.ru/api/v1/chat/completions"
)
GIGACHAT_OAUTH_URL = os.getenv(
    "GIGACHAT_OAUTH_URL", "https://ngw.devices.sberbank.ru:9443/api/v2/oauth"
)
GIGACHAT_VERIFY_SSL = os.getenv("GIGACHAT_VERIFY_SSL", "true").strip().lower() not in (
    "0",
    "false",
    "no",
)

# --- OpenAI-совместимый режим ---
API_URL = os.getenv("NEURO_API_URL", "http://localhost:11434/v1/chat/completions")
API_KEY = os.getenv("NEURO_API_KEY", "local")
MODEL = os.getenv("NEURO_MODEL", "llama3.1:8b")

# --- общее ---
SYSTEM_PROMPT = os.getenv(
    "NEURO_SYSTEM",
    "Ты — полезный ассистент. Отвечай по-русски, кратко и по существу.",
)
DB_PATH = os.getenv("NEURO_DB", "chat_memory.db")

MAX_CONTEXT_MESSAGES = 40   # сколько последних сообщений отправлять модели (память)
REQUEST_TIMEOUT = 120       # сек. ожидания ответа API
TEMPERATURE = 0.7

# ---------------------------------------------------------------------------
# UI: ANSI-цвета и утилиты вывода
# ---------------------------------------------------------------------------
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
GREEN = "\033[92m"
AMBER = "\033[93m"
CYAN = "\033[96m"
RED = "\033[91m"
GRAY = "\033[90m"


def c(text: str, color: str) -> str:
    """Окрашивает текст, если вывод в терминал."""
    if not sys.stdout.isatty():
        return text
    return f"{color}{text}{RESET}"


def print_stream_token(token: str) -> None:
    sys.stdout.write(token)
    sys.stdout.flush()


def print_info(text: str) -> None:
    print(c("  · " + text, GRAY))


def print_error(text: str) -> None:
    print(c("  ✗ " + text, RED))


class Spinner:
    """Анимация ожидания первого токена ответа."""

    FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, label: str = "думаю"):
        self._stop = threading.Event()
        prefix = c("neuro", GREEN) + c(" › ", DIM)
        self._thread = threading.Thread(target=self._run, args=(prefix, label), daemon=True)

    def _run(self, prefix: str, label: str) -> None:
        i = 0
        while not self._stop.is_set():
            frame = c(self.FRAMES[i % len(self.FRAMES)], CYAN)
            sys.stdout.write(f"\r{prefix}{frame} {c(label + '...', GRAY)}")
            sys.stdout.flush()
            i += 1
            time.sleep(0.08)

    def __enter__(self) -> "Spinner":
        self._thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self._stop.set()
        self._thread.join()
        sys.stdout.write("\r" + " " * 40 + "\r")
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# MEMORY: хранилище диалогов в SQLite
# ---------------------------------------------------------------------------
class Memory:
    """Постоянная память бота: диалоги + сообщения, переживает перезапуск."""

    def __init__(self, path: str) -> None:
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS conversations (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                title      TEXT NOT NULL DEFAULT 'Новый диалог',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS messages (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER NOT NULL REFERENCES conversations(id)
                                ON DELETE CASCADE,
                role            TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
                content         TEXT NOT NULL,
                created_at      TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_messages_conv
                ON messages(conversation_id, id);
            """
        )
        self.conn.commit()

    @staticmethod
    def _now() -> str:
        return datetime.now().isoformat(timespec="seconds")

    # --- диалоги -----------------------------------------------------------
    def create_conversation(self, title: str = "Новый диалог") -> int:
        now = self._now()
        cur = self.conn.execute(
            "INSERT INTO conversations (title, created_at, updated_at) VALUES (?,?,?)",
            (title, now, now),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def list_conversations(self) -> list:
        return self.conn.execute(
            """
            SELECT c.id, c.title, c.updated_at,
                   (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id) AS msg_count
            FROM conversations c
            ORDER BY c.updated_at DESC
            """
        ).fetchall()

    def rename_conversation(self, conv_id: int, title: str) -> None:
        self.conn.execute(
            "UPDATE conversations SET title=? WHERE id=?", (title, conv_id)
        )
        self.conn.commit()

    def delete_conversation(self, conv_id: int) -> None:
        self.conn.execute("DELETE FROM messages WHERE conversation_id=?", (conv_id,))
        self.conn.execute("DELETE FROM conversations WHERE id=?", (conv_id,))
        self.conn.commit()

    def conversation_exists(self, conv_id: int) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM conversations WHERE id=?", (conv_id,)
        ).fetchone()
        return row is not None

    # --- сообщения ---------------------------------------------------------
    def add_message(self, conv_id: int, role: str, content: str) -> None:
        now = self._now()
        self.conn.execute(
            "INSERT INTO messages (conversation_id, role, content, created_at) VALUES (?,?,?,?)",
            (conv_id, role, content, now),
        )
        self.conn.execute(
            "UPDATE conversations SET updated_at=? WHERE id=?", (now, conv_id)
        )
        self.conn.commit()

    def get_messages(self, conv_id: int, limit: int | None = None) -> list:
        """История диалога. limit — последние N сообщений (для контекста)."""
        rows = self.conn.execute(
            "SELECT role, content FROM messages WHERE conversation_id=? ORDER BY id",
            (conv_id,),
        ).fetchall()
        if limit:
            rows = rows[-limit:]
        return [{"role": r["role"], "content": r["content"]} for r in rows]

    def close(self) -> None:
        self.conn.close()


# ---------------------------------------------------------------------------
# AUTH: GigaChat OAuth (ключ авторизации → временный access_token, 30 мин)
# ---------------------------------------------------------------------------
class GigaChatAuth:
    """Получает и кэширует access_token, обновляет его до истечения срока."""

    def __init__(self, auth_key: str, scope: str, verify_ssl: bool) -> None:
        self.auth_key = auth_key
        self.scope = scope
        self.verify_ssl = verify_ssl
        self._token: str = ""
        self._expires_at: float = 0.0  # ms epoch

    def ssl_context(self) -> ssl.SSLContext | None:
        if self.verify_ssl:
            return ssl.create_default_context()
        # ВНИМАНИЕ: проверка сертификата отключена (GIGACHAT_VERIFY_SSL=false).
        # Безопасная альтернатива — установить корневой сертификат Минцифры.
        return ssl._create_unverified_context()

    def get_token(self, force: bool = False) -> str:
        now_ms = time.time() * 1000
        if not force and self._token and now_ms < self._expires_at - 60_000:
            return self._token

        if not self.auth_key:
            raise RuntimeError(
                "Не задан GIGACHAT_AUTH_KEY. Возьмите «Ключ авторизации» в ЛК "
                "developers.sber.ru (проект GigaChat API → Авторизационные данные)."
            )

        req = urllib.request.Request(
            GIGACHAT_OAUTH_URL,
            data=f"scope={self.scope}".encode("utf-8"),
            method="POST",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
                "RqUID": str(uuid.uuid4()),
                "Authorization": f"Basic {self.auth_key}",
            },
        )
        try:
            with urllib.request.urlopen(
                req, timeout=REQUEST_TIMEOUT, context=self.ssl_context()
            ) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:300]
            raise RuntimeError(
                f"OAuth GigaChat вернул HTTP {e.code}: {detail}. "
                f"Проверьте GIGACHAT_AUTH_KEY и GIGACHAT_SCOPE."
            ) from e
        except urllib.error.URLError as e:
            raise RuntimeError(self._net_error_msg(e)) from e

        token = data.get("access_token")
        if not token:
            raise RuntimeError(
                "OAuth GigaChat: в ответе нет access_token. "
                f"Ответ: {json.dumps(data, ensure_ascii=False)[:200]}"
            )
        self._token = str(token)
        self._expires_at = float(data.get("expires_at", now_ms + 30 * 60_000))
        return self._token

    def invalidate(self) -> None:
        self._token = ""
        self._expires_at = 0.0

    def _net_error_msg(self, e: urllib.error.URLError) -> str:
        reason = str(getattr(e, "reason", e))
        if isinstance(getattr(e, "reason", None), ssl.SSLError) or "certificate" in reason.lower():
            return (
                "Ошибка TLS-сертификата. У GigaChat сертификат Минцифры: установите "
                "корневой сертификат, либо временно GIGACHAT_VERIFY_SSL=false. "
                f"Детали: {reason}"
            )
        return f"Сетевая ошибка ({reason}). Проверьте доступ к {GIGACHAT_OAUTH_URL}."


# ---------------------------------------------------------------------------
# API: клиент нейросети (GigaChat или OpenAI-совместимый), со стримингом
# ---------------------------------------------------------------------------
class NeuroClient:
    """Отправляет историю диалога в модель и стримит ответ по токенам."""

    def __init__(self) -> None:
        self.provider = "gigachat" if GIGACHAT_AUTH_KEY else "openai"
        if self.provider == "gigachat":
            self.url = GIGACHAT_API_URL
            self.model = GIGACHAT_MODEL
            self.auth: GigaChatAuth | None = GigaChatAuth(
                GIGACHAT_AUTH_KEY, GIGACHAT_SCOPE, GIGACHAT_VERIFY_SSL
            )
            self.static_key = ""
        else:
            self.url = API_URL
            self.model = MODEL
            self.auth = None
            self.static_key = API_KEY

    @property
    def label(self) -> str:
        return "GigaChat" if self.provider == "gigachat" else "openai-compatible"

    def _ssl_context(self) -> ssl.SSLContext | None:
        if self.provider == "gigachat" and self.auth:
            return self.auth.ssl_context()
        return None  # системные настройки

    def _headers(self, token: str) -> dict:
        return {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Authorization": f"Bearer {token}",
        }

    def _get_token(self, force: bool = False) -> str:
        if self.provider == "gigachat" and self.auth:
            return self.auth.get_token(force=force)
        return self.static_key

    # --- публичное ----------------------------------------------------------
    def stream_reply(self, history: list):
        """Генератор токенов ответа. history — [{'role','content'}, ...]."""
        body = json.dumps(
            {
                "model": self.model,
                "messages": history,
                "temperature": TEMPERATURE,
                "max_tokens": 2048,
                "stream": True,
            },
            ensure_ascii=False,
        ).encode("utf-8")

        last_error: Exception | None = None
        for attempt in range(2):
            try:
                yield from self._stream_once(body)
                return
            except urllib.error.HTTPError as e:
                # Токен GigaChat протух — освежаем и повторяем один раз
                if e.code == 401 and self.provider == "gigachat" and attempt == 0:
                    if self.auth:
                        self.auth.invalidate()
                    last_error = e
                    continue
                detail = e.read().decode("utf-8", "replace")[:300]
                extra = (
                    " Токен отклонён: проверьте GIGACHAT_AUTH_KEY и scope."
                    if e.code == 401 and self.provider == "gigachat"
                    else ""
                )
                raise RuntimeError(f"API вернул HTTP {e.code}.{extra} {detail}") from e
            except urllib.error.URLError as e:
                if self.provider == "gigachat" and self.auth:
                    raise RuntimeError(self.auth._net_error_msg(e)) from e
                raise RuntimeError(
                    f"Не могу подключиться к {self.url} ({getattr(e, 'reason', e)}). "
                    f"Проверьте, что нейросеть запущена и NEURO_API_URL верный."
                ) from e

        if last_error:
            raise RuntimeError("Не удалось обновить токен GigaChat (HTTP 401 повторно).")

    # --- внутреннее ----------------------------------------------------------
    def _stream_once(self, body: bytes):
        req = urllib.request.Request(
            self.url,
            data=body,
            method="POST",
            headers=self._headers(self._get_token()),
        )
        with urllib.request.urlopen(
            req, timeout=REQUEST_TIMEOUT, context=self._ssl_context()
        ) as resp:
            ctype = resp.headers.get("Content-Type", "")
            if "text/event-stream" not in ctype:
                # Сервер вернул цельный JSON вместо потока
                data = json.loads(resp.read().decode("utf-8"))
                yield self._extract_json_content(data)
                return

            for raw_line in resp:
                line = raw_line.decode("utf-8", "replace").strip()
                if not line or not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if not payload or payload == "[DONE]":
                    continue
                try:
                    chunk = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                delta = (
                    chunk.get("choices", [{}])[0].get("delta", {}).get("content")
                    or chunk.get("choices", [{}])[0].get("message", {}).get("content")
                    or ""
                )
                if delta:
                    yield delta

    @staticmethod
    def _extract_json_content(data: dict) -> str:
        try:
            return str(data["choices"][0]["message"]["content"]).strip()
        except (KeyError, IndexError, TypeError) as e:
            raise RuntimeError(
                f"Неожиданный формат ответа API: {json.dumps(data, ensure_ascii=False)[:300]}"
            ) from e


# ---------------------------------------------------------------------------
# BOT: собираем всё вместе
# ---------------------------------------------------------------------------
HELP = f"""
{c('КОМАНДЫ', BOLD)}
  {c('/help', CYAN)}           — эта справка
  {c('/new [название]', CYAN)} — начать новый диалог
  {c('/list', CYAN)}           — список сохранённых диалогов
  {c('/load N', CYAN)}         — продолжить диалог №N (память подгрузится)
  {c('/rename ТЕКСТ', CYAN)}   — переименовать текущий диалог
  {c('/delete N', CYAN)}       — удалить диалог №N
  {c('/history [N]', CYAN)}    — показать последние N сообщений (по умолч. 10)
  {c('/model ИМЯ', CYAN)}      — сменить модель на лету (напр. GigaChat-Max)
  {c('/clear', CYAN)}          — очистить экран
  {c('/exit', CYAN)}           — выход
"""


class ChatBot:
    def __init__(self) -> None:
        self.memory = Memory(DB_PATH)
        self.client = NeuroClient()
        self.conv_id: int | None = None

    # --- запуск ------------------------------------------------------------
    def run(self) -> None:
        self._banner()
        # Продолжаем самый свежий диалог, либо создаём новый
        convs = self.memory.list_conversations()
        if convs:
            self.conv_id = int(convs[0]["id"])
            print_info(
                f"Продолжаем диалог №{self.conv_id} «{convs[0]['title']}» "
                f"(память: {convs[0]['msg_count']} сообщ.). /new — новый диалог."
            )
        else:
            self.conv_id = self.memory.create_conversation()
            print_info("Создан первый диалог. Просто пишите сообщение.")

        while True:
            try:
                raw = input(c("вы", AMBER) + c("    › ", DIM)).strip()
            except (EOFError, KeyboardInterrupt):
                print()
                self._bye()
                break
            if not raw:
                continue
            if raw.startswith("/"):
                if not self._command(raw):
                    break
                continue
            self._ask(raw)

        self.memory.close()

    # --- main loop ----------------------------------------------------------
    def _ask(self, text: str) -> None:
        assert self.conv_id is not None
        # Если это первое сообщение диалога — используем его как название
        self._maybe_autotitle(text)
        # 1) сохраняем сообщение пользователя в память
        self.memory.add_message(self.conv_id, "user", text)
        # 2) собираем контекст: системный промпт + последние N сообщений
        history = [{"role": "system", "content": SYSTEM_PROMPT}]
        history += self.memory.get_messages(self.conv_id, limit=MAX_CONTEXT_MESSAGES)
        # 3) спрашиваем нейросеть: спиннер до первого токена, дальше — стрим
        prefix = c("neuro", GREEN) + c(" › ", DIM)
        full_reply = ""
        try:
            tokens = self.client.stream_reply(history)
            with Spinner():
                first = next(tokens, None)
            if first is None:
                print_info("Модель вернула пустой ответ.")
                return
            sys.stdout.write("\n" + prefix)
            print_stream_token(first)
            full_reply += first
            for token in tokens:
                print_stream_token(token)
                full_reply += token
            sys.stdout.write("\n\n")
            sys.stdout.flush()
        except RuntimeError as e:
            print_error(str(e))
            return
        # 4) сохраняем ответ в память
        self.memory.add_message(self.conv_id, "assistant", full_reply)

    def _maybe_autotitle(self, text: str) -> None:
        assert self.conv_id is not None
        if len(self.memory.get_messages(self.conv_id)) == 0:
            title = text if len(text) <= 42 else text[:41] + "…"
            self.memory.rename_conversation(self.conv_id, title)

    # --- команды ------------------------------------------------------------
    def _command(self, raw: str) -> bool:
        """Обработка /команд. Возвращает False, если нужно выйти."""
        parts = raw.split(maxsplit=1)
        cmd, arg = parts[0].lower(), (parts[1].strip() if len(parts) > 1 else "")

        if cmd in ("/exit", "/quit", "/q"):
            self._bye()
            return False
        if cmd == "/help":
            print(HELP)
        elif cmd == "/new":
            title = arg or "Новый диалог"
            self.conv_id = self.memory.create_conversation(title)
            print_info(f"Новый диалог №{self.conv_id} «{title}». Память чиста.")
        elif cmd == "/list":
            self._list()
        elif cmd == "/load":
            self._load(arg)
        elif cmd == "/rename":
            if not arg:
                print_error("Укажите название: /rename Текст")
            else:
                self.memory.rename_conversation(self.conv_id, arg)
                print_info(f"Диалог переименован в «{arg}».")
        elif cmd == "/delete":
            self._delete(arg)
        elif cmd == "/history":
            limit = int(arg) if arg.isdigit() else 10
            self._history(limit)
        elif cmd == "/model":
            if not arg:
                print_info(f"Текущая модель: {self.client.model} ({self.client.label})")
            else:
                self.client.model = arg
                print_info(f"Модель переключена на «{arg}».")
        elif cmd == "/clear":
            os.system("cls" if os.name == "nt" else "clear")
            self._banner()
        else:
            print_error(f"Неизвестная команда «{cmd}». /help — справка.")
        return True

    def _list(self) -> None:
        convs = self.memory.list_conversations()
        if not convs:
            print_info("Сохранённых диалогов нет.")
            return
        print(c("\n  СОХРАНЁННЫЕ ДИАЛОГИ", BOLD))
        for r in convs:
            mark = c("●", GREEN) if r["id"] == self.conv_id else c("○", GRAY)
            ts = r["updated_at"].replace("T", " ")
            num = c(f"№{r['id']:>4}", CYAN)
            count = c(f"{r['msg_count']:>3} сообщ.", GRAY)
            print(f"  {mark} {num}  {r['title'][:40]:<40} {count} {c(ts, DIM)}")
        print()

    def _load(self, arg: str) -> None:
        if not arg.isdigit():
            print_error("Укажите номер: /load N (номера — в /list)")
            return
        conv_id = int(arg)
        if not self.memory.conversation_exists(conv_id):
            print_error(f"Диалог №{conv_id} не найден.")
            return
        self.conv_id = conv_id
        n = len(self.memory.get_messages(conv_id))
        print_info(f"Диалог №{conv_id} загружен. Память: {n} сообщений — модель их помнит.")
        self._history(4)

    def _delete(self, arg: str) -> None:
        if not arg.isdigit():
            print_error("Укажите номер: /delete N")
            return
        conv_id = int(arg)
        if not self.memory.conversation_exists(conv_id):
            print_error(f"Диалог №{conv_id} не найден.")
            return
        self.memory.delete_conversation(conv_id)
        print_info(f"Диалог №{conv_id} удалён.")
        if conv_id == self.conv_id:
            convs = self.memory.list_conversations()
            self.conv_id = (
                int(convs[0]["id"]) if convs else self.memory.create_conversation()
            )
            print_info(f"Переключился на диалог №{self.conv_id}.")

    def _history(self, limit: int) -> None:
        msgs = self.memory.get_messages(self.conv_id, limit=limit)
        if not msgs:
            print_info("В этом диалоге пока нет сообщений.")
            return
        print(c(f"\n  ПОСЛЕДНИЕ {len(msgs)} СООБЩЕНИЙ", BOLD))
        for m in msgs:
            who = c("вы   ", AMBER) if m["role"] == "user" else c("neuro", GREEN)
            snippet = m["content"].replace("\n", " ")[:90]
            print(f"  {who} {c('›', DIM)} {snippet}")
        print()

    # --- прочее -------------------------------------------------------------
    def _banner(self) -> None:
        print(
            c(
                r"""
  ╔══════════════════════════════════════════════════════╗
  ║   ███╗   ██╗███████╗██╗   ██╗██████╗  ██████╗        ║
  ║   ████╗  ██║██╔════╝██║   ██║██╔══██╗██╔═══██╗       ║
  ║   ██╔██╗ ██║█████╗  ██║   ██║██████╔╝██║   ██║       ║
  ║   ██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██║   ██║       ║
  ║   ██║ ╚████║███████╗╚██████╔╝██║  ██║╚██████╔╝       ║
  ║   ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ TERM   ║
  ╚══════════════════════════════════════════════════════╝""",
                GREEN,
            )
        )
        print(c(f"  нейросеть: {self.client.label} · модель: {self.client.model}", GRAY))
        print(c(f"  endpoint: {self.client.url}", GRAY))
        print(c(f"  память: {DB_PATH} · контекст: последние {MAX_CONTEXT_MESSAGES} сообщ.", GRAY))
        if self.client.provider == "gigachat":
            ssl_note = "проверка TLS вкл" if GIGACHAT_VERIFY_SSL else "проверка TLS ВЫКЛ"
            print(c(f"  GigaChat OAuth: {GIGACHAT_SCOPE} · {ssl_note}", GRAY))
        print(c("  /help — команды, /exit — выход\n", GRAY))

    @staticmethod
    def _bye() -> None:
        print(c("  Сеанс завершён. История сохранена в памяти. Пока!\n", GREEN))


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    try:
        ChatBot().run()
    except sqlite3.Error as e:
        print_error(f"Ошибка базы памяти: {e}")
        sys.exit(1)
