"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { PanelLeft, X } from "lucide-react";
import Composer from "./Composer";
import MessageList from "./MessageList";
import Sidebar from "./Sidebar";
import type { AiPublicConfig, ConversationMeta, UiMessage } from "./types";

interface ChatAppProps {
  config: AiPublicConfig;
}

export default function ChatApp({ config }: ChatAppProps) {
  const [conversations, setConversations] = useState<ConversationMeta[] | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [streamText, setStreamText] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const abortRef = useRef<AbortController | null>(null);
  const accRef = useRef("");
  const interruptedRef = useRef(false);

  /* ---------- загрузка списка диалогов ---------- */
  const loadConversations = useCallback(async () => {
    try {
      const res = await fetch("/api/conversations", { cache: "no-store" });
      if (res.ok) setConversations(await res.json());
    } catch {
      /* сеть недоступна — молча */
    }
  }, []);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  /* ---------- загрузка сообщений активного диалога ---------- */
  useEffect(() => {
    if (!activeId) {
      setMessages([]);
      return;
    }
    let alive = true;
    (async () => {
      try {
        const res = await fetch(`/api/conversations/${activeId}`, { cache: "no-store" });
        if (!alive || !res.ok) return;
        const data = await res.json();
        setMessages(
          (data.messages as UiMessage[]).filter((m) => m.role !== "system"),
        );
      } catch {
        /* noop */
      }
    })();
    return () => {
      alive = false;
    };
  }, [activeId]);

  /* ---------- автоскрытие ошибки ---------- */
  useEffect(() => {
    if (!error) return;
    const t = setTimeout(() => setError(null), 7000);
    return () => clearTimeout(t);
  }, [error]);

  /* ---------- отправка ---------- */
  const send = useCallback(
    async (rawOverride?: string) => {
      const content = (rawOverride ?? input).trim();
      if (!content || streaming) return;

      setInput("");
      setError(null);
      interruptedRef.current = false;

      try {
        // создаём диалог лениво при первом сообщении
        let convId = activeId;
        if (!convId) {
          const res = await fetch("/api/conversations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
          });
          if (!res.ok) throw new Error("Не удалось создать диалог");
          const conv: ConversationMeta = await res.json();
          convId = conv.id;
          setActiveId(convId);
          setConversations((prev) => (prev ? [conv, ...prev] : [conv]));
        }

        const userMsg: UiMessage = {
          id: crypto.randomUUID(),
          role: "user",
          content,
          createdAt: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, userMsg]);
        setStreaming(true);
        setStreamText("");
        accRef.current = "";

        const ac = new AbortController();
        abortRef.current = ac;

        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ conversationId: convId, content }),
          signal: ac.signal,
        });

        if (!res.ok || !res.body) {
          const j = (await res.json().catch(() => null)) as { error?: string } | null;
          throw new Error(j?.error ?? `Сервер ответил HTTP ${res.status}`);
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          accRef.current += decoder.decode(value, { stream: true });
          setStreamText(accRef.current);
        }

        if (accRef.current.trim()) {
          const replyMsg: UiMessage = {
            id: crypto.randomUUID(),
            role: "assistant",
            content: accRef.current,
            createdAt: new Date().toISOString(),
          };
          setMessages((prev) => [...prev, replyMsg]);
        }
      } catch (e) {
        if ((e as Error).name === "AbortError") {
          interruptedRef.current = true;
        } else {
          setError((e as Error).message || "Ошибка запроса");
        }
      } finally {
        // при ручной остановке — оставляем недопечатанный кусок как сообщение
        if (interruptedRef.current && accRef.current.trim()) {
          const partial: UiMessage = {
            id: crypto.randomUUID(),
            role: "assistant",
            content: accRef.current + " ▍*остановлено*",
            createdAt: new Date().toISOString(),
          };
          setMessages((prev) => [...prev, partial]);
        }
        abortRef.current = null;
        accRef.current = "";
        setStreamText("");
        setStreaming(false);
        void loadConversations();
      }
    },
    [input, streaming, activeId, loadConversations],
  );

  const stop = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  /* ---------- действия с диалогами ---------- */
  const selectConversation = useCallback(
    (id: string) => {
      if (streaming || id === activeId) {
        setSidebarOpen(false);
        return;
      }
      setActiveId(id);
      setSidebarOpen(false);
    },
    [streaming, activeId],
  );

  const newChat = useCallback(() => {
    if (streaming) return;
    setActiveId(null);
    setMessages([]);
    setSidebarOpen(false);
  }, [streaming]);

  const deleteConversation = useCallback(
    async (id: string) => {
      setConversations((prev) => prev?.filter((c) => c.id !== id) ?? prev);
      if (id === activeId) {
        setActiveId(null);
        setMessages([]);
      }
      try {
        await fetch(`/api/conversations/${id}`, { method: "DELETE" });
      } catch {
        void loadConversations();
      }
    },
    [activeId, loadConversations],
  );

  const renameConversation = useCallback(async (id: string, title: string) => {
    setConversations(
      (prev) => prev?.map((c) => (c.id === id ? { ...c, title } : c)) ?? prev,
    );
    try {
      await fetch(`/api/conversations/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title }),
      });
    } catch {
      /* noop */
    }
  }, []);

  const suggest = useCallback((text: string) => {
    setInput(text);
    setTimeout(() => document.getElementById("composer-input")?.focus(), 30);
  }, []);

  const activeTitle =
    activeId === null
      ? "новый_диалог"
      : (conversations?.find((c) => c.id === activeId)?.title ?? "диалог");

  /* ---------- разметка ---------- */
  return (
    <div className="relative flex h-dvh overflow-hidden bg-void">
      <div className="bg-glow pointer-events-none absolute inset-0" />
      <div className="bg-grid pointer-events-none absolute inset-0" />

      <Sidebar
        conversations={conversations}
        activeId={activeId}
        configured={config.configured}
        provider={config.provider}
        model={config.model}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onSelect={selectConversation}
        onNew={newChat}
        onDelete={deleteConversation}
        onRename={renameConversation}
      />

      <main className="relative flex min-w-0 flex-1 flex-col">
        {/* шапка */}
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-edge bg-panel/60 px-4 backdrop-blur-sm sm:px-6">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-lg border border-edge p-2 text-fog transition hover:text-ink md:hidden"
            title="История диалогов"
          >
            <PanelLeft size={15} />
          </button>

          <div className="flex min-w-0 items-baseline gap-2.5">
            <span className="text-phosphor-dim">›</span>
            <span className="truncate text-[13px] text-ink">{activeTitle}</span>
            {messages.length > 0 && (
              <span className="shrink-0 text-[10px] text-fog/70">
                [{messages.length}]
              </span>
            )}
          </div>

          <div className="ml-auto flex items-center gap-2.5">
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                config.configured ? "animate-pulse-dot bg-phosphor" : "bg-ambera"
              }`}
            />
            <span className="hidden max-w-[220px] truncate text-[11px] text-fog sm:block">
              {config.model}
            </span>
          </div>
        </header>

        {/* сообщения */}
        <MessageList
          messages={messages}
          streaming={streaming}
          streamText={streamText}
          model={config.model}
          onSuggest={suggest}
        />

        {/* баннер ошибки */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className="absolute inset-x-0 bottom-28 z-10 mx-auto w-fit max-w-[92%]"
            >
              <div className="flex items-center gap-3 rounded-xl border border-red-400/40 bg-[#1a0d0e]/95 px-4 py-2.5 text-[12px] text-red-200 shadow-2xl">
                <span className="text-red-400">✗</span>
                <span className="leading-snug">{error}</span>
                <button
                  onClick={() => setError(null)}
                  className="rounded p-0.5 text-red-300/70 hover:text-red-200"
                >
                  <X size={13} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <Composer
          value={input}
          streaming={streaming}
          onChange={setInput}
          onSend={() => send()}
          onStop={stop}
        />
      </main>
    </div>
  );
}
