"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  MessageSquareText,
  Pencil,
  Plus,
  SquareTerminal,
  Trash2,
  X,
} from "lucide-react";
import { formatDayTime } from "./format";
import type { ConversationMeta } from "./types";

interface SidebarProps {
  conversations: ConversationMeta[] | null;
  activeId: string | null;
  configured: boolean;
  provider: "gigachat" | "openai" | "demo";
  model: string;
  open: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
}

export default function Sidebar({
  conversations,
  activeId,
  configured,
  provider,
  model,
  open,
  onClose,
  onSelect,
  onNew,
  onDelete,
  onRename,
}: SidebarProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const editRef = useRef<HTMLInputElement>(null);
  const confirmTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (editingId) editRef.current?.select();
  }, [editingId]);

  useEffect(
    () => () => {
      if (confirmTimer.current) clearTimeout(confirmTimer.current);
    },
    [],
  );

  const startRename = (c: ConversationMeta) => {
    setEditingId(c.id);
    setEditValue(c.title);
  };

  const commitRename = () => {
    if (editingId && editValue.trim()) onRename(editingId, editValue.trim());
    setEditingId(null);
  };

  const askDelete = (id: string) => {
    setConfirmDeleteId(id);
    if (confirmTimer.current) clearTimeout(confirmTimer.current);
    confirmTimer.current = setTimeout(() => setConfirmDeleteId(null), 2600);
  };

  return (
    <>
      {/* backdrop для мобильных */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/70 backdrop-blur-sm md:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[292px] shrink-0 flex-col border-r border-edge bg-panel transition-transform duration-300 ease-out md:static md:z-auto md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* логотип */}
        <div className="border-b border-edge px-5 pb-5 pt-5">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-phosphor/30 bg-phosphor/10 text-phosphor shadow-[0_0_18px_rgba(92,255,157,0.15)]">
              <SquareTerminal size={18} strokeWidth={1.8} />
            </div>
            <div>
              <div className="font-display text-[13px] font-bold tracking-wider text-white">
                НЕЙРО<span className="text-phosphor">//</span>ЧАТ
              </div>
              <div className="mt-0.5 text-[10px] uppercase tracking-[0.2em] text-fog">
                terminal · memory
              </div>
            </div>
          </div>

          {/* статус API */}
          <div className="mt-4 flex items-center gap-2 rounded-lg border border-edge bg-panel2 px-3 py-2 text-[11px]">
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                configured
                  ? "animate-pulse-dot bg-phosphor"
                  : "bg-ambera"
              }`}
            />
            <span className={configured ? "text-phosphor" : "text-ambera"}>
              {configured
                ? provider === "gigachat"
                  ? "GigaChat API"
                  : "API подключён"
                : "демо-режим"}
            </span>
            <span className="ml-auto truncate text-fog" title={model}>
              {model}
            </span>
          </div>

          <button
            onClick={onNew}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-phosphor/35 bg-phosphor/10 px-3 py-2.5 text-[12px] font-medium text-phosphor transition hover:bg-phosphor/20 hover:shadow-[0_0_24px_rgba(92,255,157,0.18)]"
          >
            <Plus size={14} strokeWidth={2.4} />
            новый диалог
          </button>
        </div>

        {/* список диалогов */}
        <div className="flex items-center justify-between px-5 pb-2 pt-4 text-[10px] uppercase tracking-[0.22em] text-fog">
          <span>история</span>
          <span>{conversations?.length ?? 0}</span>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-4">
          {conversations === null ? (
            <div className="space-y-2 px-2 pt-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <div
                  key={i}
                  className="h-12 animate-pulse rounded-lg border border-edge bg-panel2"
                  style={{ animationDelay: `${i * 120}ms` }}
                />
              ))}
            </div>
          ) : conversations.length === 0 ? (
            <div className="flex flex-col items-center gap-2 px-4 py-10 text-center text-[11px] leading-relaxed text-fog">
              <MessageSquareText size={20} className="text-edge2" />
              диалогов пока нет — напишите первое сообщение, всё сохранится
            </div>
          ) : (
            <ul className="space-y-1">
              <AnimatePresence initial={false}>
                {conversations.map((c) => {
                  const active = c.id === activeId;
                  const renaming = editingId === c.id;
                  const confirming = confirmDeleteId === c.id;
                  return (
                    <motion.li
                      key={c.id}
                      layout
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -14, height: 0, marginBottom: 0 }}
                      transition={{ duration: 0.22, ease: "easeOut" }}
                      className="overflow-hidden"
                    >
                      <div
                        className={`group relative cursor-pointer rounded-lg border px-3 py-2.5 transition ${
                          active
                            ? "border-phosphor/30 bg-phosphor/[0.07]"
                            : "border-transparent hover:border-edge hover:bg-panel2"
                        }`}
                        onClick={() => !renaming && onSelect(c.id)}
                      >
                        {active && (
                          <span className="absolute inset-y-2 left-0 w-[2px] rounded-full bg-phosphor shadow-[0_0_8px_rgba(92,255,157,0.7)]" />
                        )}

                        {renaming ? (
                          <div
                            className="flex items-center gap-1.5"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <input
                              ref={editRef}
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") commitRename();
                                if (e.key === "Escape") setEditingId(null);
                              }}
                              className="min-w-0 flex-1 rounded border border-edge2 bg-void px-2 py-1 text-[12px] text-ink outline-none focus:border-phosphor/50"
                            />
                            <button
                              onClick={commitRename}
                              className="rounded p-1 text-phosphor hover:bg-phosphor/10"
                              title="Сохранить"
                            >
                              <Check size={13} />
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="rounded p-1 text-fog hover:bg-edge"
                              title="Отмена"
                            >
                              <X size={13} />
                            </button>
                          </div>
                        ) : (
                          <>
                            <div className="truncate pr-12 text-[12.5px] leading-snug text-ink">
                              {c.title}
                            </div>
                            <div className="mt-1 flex items-center gap-2 text-[10px] text-fog">
                              <span>{formatDayTime(c.updatedAt)}</span>
                              <span className="text-edge2">·</span>
                              <span>{c.messageCount} сообщ.</span>
                            </div>

                            <div
                              className="absolute right-2 top-2 flex items-center gap-0.5 md:opacity-0 md:transition md:group-hover:opacity-100"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {confirming ? (
                                <button
                                  onClick={() => {
                                    setConfirmDeleteId(null);
                                    onDelete(c.id);
                                  }}
                                  className="rounded border border-red-400/40 bg-red-400/10 px-1.5 py-1 text-[9px] uppercase tracking-wider text-red-300"
                                  title="Подтвердить удаление"
                                >
                                  точно?
                                </button>
                              ) : (
                                <>
                                  <button
                                    onClick={() => startRename(c)}
                                    className="rounded p-1.5 text-fog hover:bg-edge hover:text-ink"
                                    title="Переименовать"
                                  >
                                    <Pencil size={12} />
                                  </button>
                                  <button
                                    onClick={() => askDelete(c.id)}
                                    className="rounded p-1.5 text-fog hover:bg-red-400/10 hover:text-red-300"
                                    title="Удалить"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    </motion.li>
                  );
                })}
              </AnimatePresence>
            </ul>
          )}
        </div>

        {/* подвал */}
        <div className="border-t border-edge px-5 py-3 text-[10px] leading-relaxed text-fog">
          <div className="flex justify-between">
            <span>память: postgresql</span>
            <span className="text-phosphor-dim">контекст: 40</span>
          </div>
          {!configured && (
            <div className="mt-1 text-ambera/80">
              задайте GIGACHAT_AUTH_KEY в .env → GigaChat
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
