/**
 * Серверный клиент нейросети.
 *
 * Поддерживает два режима (авто-определение):
 *
 * 1) GigaChat (Сбер) — если задан GIGACHAT_AUTH_KEY или AI_PROVIDER=gigachat.
 *    OAuth-обмен ключа на временный токен (30 мин), авто-обновление,
 *    SSE-стриминг, адреса по умолчанию:
 *      OAuth : https://ngw.devices.sberbank.ru:9443/api/v2/oauth
 *      Chat  : https://gigachat.devices.sberbank.ru/api/v1/chat/completions
 *
 *    Переменные:
 *      GIGACHAT_AUTH_KEY  — «Ключ авторизации» из ЛК developers.sber.ru
 *      GIGACHAT_SCOPE     — GIGACHAT_API_PERS (по умолч.) | _B2B | _CORP
 *      AI_MODEL           — GigaChat | GigaChat-Pro | GigaChat-Max | …
 *
 * 2) OpenAI-совместимый API — если задан AI_API_URL
 *    (OpenAI, Ollama, LM Studio, vLLM, llama.cpp server …):
 *      AI_API_URL / AI_API_KEY / AI_MODEL
 *
 * Общие переменные:
 *      AI_SYSTEM      — системный промпт
 *      AI_VERIFY_SSL  — "false" отключит проверку TLS (у GigaChat
 *                       сертификат Минцифры часто не в системном хранилище;
 *                       безопасный путь — установить корневой сертификат и
 *                       NODE_EXTRA_CA_CERTS вместо отключения проверки)
 *
 * Если ничего не задано — демо-режим (локальный ответчик).
 */

import { Agent, fetch as undiciFetch } from "undici";

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

/* ----------------------------- конфиг ----------------------------- */

const rawProvider = (process.env.AI_PROVIDER ?? "").toLowerCase();
const GIGACHAT_AUTH_KEY = process.env.GIGACHAT_AUTH_KEY ?? "";
const GIGACHAT_SCOPE = process.env.GIGACHAT_SCOPE ?? "GIGACHAT_API_PERS";
const GIGACHAT_OAUTH_URL =
  process.env.GIGACHAT_OAUTH_URL ??
  "https://ngw.devices.sberbank.ru:9443/api/v2/oauth";
const GIGACHAT_CHAT_URL =
  process.env.GIGACHAT_API_URL ??
  "https://gigachat.devices.sberbank.ru/api/v1/chat/completions";

const API_URL = process.env.AI_API_URL ?? "";
const API_KEY = process.env.AI_API_KEY ?? "local";

const SYSTEM_PROMPT =
  process.env.AI_SYSTEM ??
  "Ты — полезный ассистент. Отвечай по-русски, кратко и по существу.";

const INSECURE_TLS = (process.env.AI_VERIFY_SSL ?? "true").toLowerCase() === "false";

const PROVIDER: "gigachat" | "openai" | "demo" =
  rawProvider === "gigachat" || (rawProvider !== "openai" && GIGACHAT_AUTH_KEY)
    ? "gigachat"
    : API_URL || rawProvider === "openai"
      ? "openai"
      : "demo";

const MODEL =
  process.env.AI_MODEL ??
  (PROVIDER === "gigachat" ? "GigaChat" : PROVIDER === "demo" ? "demo-local" : "local-model");

export function aiConfig() {
  return {
    configured: PROVIDER !== "demo",
    provider: PROVIDER,
    model: PROVIDER === "demo" ? "demo-local" : MODEL,
    systemPrompt: SYSTEM_PROMPT,
  };
}

export function systemMessage(): ChatMessage {
  return { role: "system", content: SYSTEM_PROMPT };
}

/* ------------------------- HTTP с TLS-переключателем ------------------------- */

const insecureAgent = INSECURE_TLS
  ? new Agent({ connect: { rejectUnauthorized: false } })
  : null;

interface HttpResponse {
  ok: boolean;
  status: number;
  headers: { get(name: string): string | null };
  body: ReadableStream<Uint8Array> | null;
  text(): Promise<string>;
}

async function tlsFetch(
  url: string,
  init: { method: string; headers: Record<string, string>; body?: string },
): Promise<HttpResponse> {
  const res = insecureAgent
    ? await undiciFetch(url, { ...init, dispatcher: insecureAgent })
    : await fetch(url, init);
  return res as unknown as HttpResponse;
}

/** Человекочитаемая формулировка частых сетевых/TLS ошибок. */
function friendlyNetError(e: unknown, url: string): string {
  const err = e as Error & { cause?: { code?: string } };
  const code = err?.cause?.code ?? "";
  if (
    code.includes("CERT") ||
    code.includes("SSL") ||
    code.includes("UNABLE_TO_VERIFY") ||
    /certificate/i.test(err?.message ?? "")
  ) {
    return (
      `Ошибка TLS-сертификата при обращении к ${url}. У GigaChat сертификат ` +
      `Минцифры: либо установите корневой сертификат (и NODE_EXTRA_CA_CERTS), ` +
      `либо временно задайте AI_VERIFY_SSL=false в .env`
    );
  }
  return `Сетевая ошибка при обращении к ${url}: ${err?.message ?? e}`;
}

/* ------------------------- GigaChat OAuth-токен ------------------------- */

let tokenCache: { value: string; expiresAt: number } | null = null;

function invalidateToken() {
  tokenCache = null;
}

async function getGigaChatToken(forceRefresh = false): Promise<string> {
  if (
    !forceRefresh &&
    tokenCache &&
    Date.now() < tokenCache.expiresAt - 60_000
  ) {
    return tokenCache.value;
  }

  if (!GIGACHAT_AUTH_KEY) {
    throw new Error(
      "Не задан GIGACHAT_AUTH_KEY. Возьмите «Ключ авторизации» в ЛК developers.sber.ru (проект GigaChat API → Авторизационные данные).",
    );
  }

  let res: HttpResponse;
  try {
    res = await tlsFetch(GIGACHAT_OAUTH_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
        RqUID: crypto.randomUUID(),
        Authorization: `Basic ${GIGACHAT_AUTH_KEY}`,
      },
      body: `scope=${encodeURIComponent(GIGACHAT_SCOPE)}`,
    });
  } catch (e) {
    throw new Error(friendlyNetError(e, GIGACHAT_OAUTH_URL));
  }

  const text = await res.text();
  if (!res.ok) {
    throw new Error(
      `OAuth GigaChat вернул HTTP ${res.status}: ${text.slice(0, 300)}. ` +
        `Проверьте GIGACHAT_AUTH_KEY и GIGACHAT_SCOPE.`,
    );
  }

  let json: { access_token?: string; expires_at?: number };
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error("OAuth GigaChat вернул не-JSON ответ.");
  }
  if (!json.access_token) {
    throw new Error(`OAuth GigaChat: в ответе нет access_token (${text.slice(0, 200)})`);
  }

  tokenCache = {
    value: json.access_token,
    expiresAt: Number(json.expires_at ?? Date.now() + 30 * 60_000),
  };
  return tokenCache.value;
}

/* ------------------------- SSE-парсер (общий) ------------------------- */

/** Читает текстовый SSE-поток и передаёт текст дельт контентом в emit. */
async function pipeSSE(
  body: ReadableStream<Uint8Array>,
  emit: (token: string) => void,
): Promise<void> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const raw of lines) {
      const line = raw.trim();
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      try {
        const json = JSON.parse(data);
        const delta =
          json?.choices?.[0]?.delta?.content ??
          json?.choices?.[0]?.message?.content ??
          "";
        if (delta) emit(String(delta));
      } catch {
        // неполный JSON-чанк — пропускаем
      }
    }
  }
}

/** Разбор непотокового (JSON) ответа — OpenAI-совместимый формат. */
function pickJsonContent(text: string): string {
  try {
    const json = JSON.parse(text);
    return String(
      json?.choices?.[0]?.message?.content ?? "Пустой ответ от модели.",
    );
  } catch {
    return text.slice(0, 4000);
  }
}

/* ------------------------- публичное API ------------------------- */

/**
 * Возвращает ReadableStream<string> с токенами ответа модели.
 * Используется роутом /api/chat для потоковой отдачи в браузер.
 */
export function streamChat(history: ChatMessage[]): ReadableStream<string> {
  if (PROVIDER === "gigachat") return gigachatStream(history);
  if (PROVIDER === "openai") return openaiStream(history);
  return demoStream(history);
}

/* ------------------------- GigaChat ------------------------- */

function gigachatStream(history: ChatMessage[]): ReadableStream<string> {
  return new ReadableStream<string>({
    async start(controller) {
      const fail = (msg: string) => {
        controller.enqueue(`[ошибка] ${msg}`);
        controller.close();
      };

      for (let attempt = 0; attempt < 2; attempt++) {
        let res: HttpResponse;
        try {
          const token = await getGigaChatToken(attempt > 0);
          res = await tlsFetch(GIGACHAT_CHAT_URL, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "text/event-stream",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              model: MODEL,
              messages: history,
              temperature: 0.7,
              stream: true,
            }),
          });
        } catch (e) {
          fail(e instanceof Error ? e.message : friendlyNetError(e, GIGACHAT_CHAT_URL));
          return;
        }

        // Токен протух между запросами — обновляем и повторяем один раз
        if (res.status === 401 && attempt === 0) {
          invalidateToken();
          continue;
        }

        if (!res.ok) {
          const detail = (await res.text().catch(() => "")).slice(0, 300);
          let extra = "";
          if (res.status === 401) {
            extra = " Токен отклонён: проверьте GIGACHAT_AUTH_KEY и scope.";
          }
          fail(`GigaChat вернул HTTP ${res.status}.${extra} ${detail}`);
          return;
        }

        const contentType = res.headers.get("content-type") ?? "";
        if (!res.body) {
          fail("Пустое тело ответа GigaChat.");
          return;
        }

        if (!contentType.includes("text/event-stream")) {
          controller.enqueue(pickJsonContent(await res.text()));
          controller.close();
          return;
        }

        await pipeSSE(res.body, (t) => controller.enqueue(t));
        controller.close();
        return;
      }
    },
  });
}

/* --------------------- OpenAI-совместимый API --------------------- */

function openaiStream(history: ChatMessage[]): ReadableStream<string> {
  return new ReadableStream<string>({
    async start(controller) {
      const fail = (msg: string) => {
        controller.enqueue(`[ошибка] ${msg}`);
        controller.close();
      };

      let res: HttpResponse;
      try {
        res = await tlsFetch(API_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${API_KEY}`,
          },
          body: JSON.stringify({
            model: MODEL,
            messages: history,
            temperature: 0.7,
            stream: true,
          }),
        });
      } catch (e) {
        fail(friendlyNetError(e, API_URL) + ". Проверьте, что нейросеть запущена.");
        return;
      }

      if (!res.ok) {
        const detail = (await res.text().catch(() => "")).slice(0, 300);
        fail(`API вернул HTTP ${res.status}. ${detail}`);
        return;
      }

      const contentType = res.headers.get("content-type") ?? "";
      if (!res.body) {
        fail("Пустое тело ответа API.");
        return;
      }

      if (!contentType.includes("text/event-stream")) {
        controller.enqueue(pickJsonContent(await res.text()));
        controller.close();
        return;
      }

      await pipeSSE(res.body, (t) => controller.enqueue(t));
      controller.close();
    },
  });
}

/* --------------------- Демо-режим --------------------- */

const DEMO_TEMPLATES: string[] = [
  "Принял: «{q}». Пока работаю в демо-режиме — настоящая нейросеть ещё не подключена. Для подключения **GigaChat** задайте `GIGACHAT_AUTH_KEY` (ключ авторизации из ЛК developers.sber.ru) в файле `.env` — или `AI_API_URL` для любого OpenAI-совместимого endpoint.\n\nКстати, я запомнил это сообщение: история диалога уже сохранена в PostgreSQL и отправляется модели контекстом при каждом запросе.",
  "Записал в память. Ваше сообщение из {n} слов теперь часть контекста этого диалога. Чтобы оживить меня GigaChat:\n\n```\nAI_PROVIDER=gigachat\nGIGACHAT_AUTH_KEY=MW...  # ключ авторизации\nAI_MODEL=GigaChat\nAI_VERIFY_SSL=false      # если ругается на сертификат\n```",
  "«{q}» — интересно. Я демо-ответчик, но пайплайн полностью боевой: сообщение → PostgreSQL → контекст → модель → стриминг ответа токен за токеном. Осталось указать `GIGACHAT_AUTH_KEY`, и терминал оживёт.",
  "Вижу ваш запрос («{q}»). Демо-режим активен, потому что не задан ни `GIGACHAT_AUTH_KEY`, ни `AI_API_URL`. Все диалоги при этом сохраняются — см. сайдбар слева: там можно переключаться между ними, и каждый помнит свой контекст.",
];

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

function demoReply(history: ChatMessage[]): string {
  const lastUser = [...history].reverse().find((m) => m.role === "user");
  const q = (lastUser?.content ?? "").replace(/\s+/g, " ").trim();
  const short = q.length > 80 ? q.slice(0, 79) + "…" : q;
  const words = q ? q.split(" ").length : 0;
  const tpl =
    DEMO_TEMPLATES[hashCode(q || String(Date.now())) % DEMO_TEMPLATES.length];
  return tpl.replaceAll("{q}", short).replaceAll("{n}", String(words));
}

function demoStream(history: ChatMessage[]): ReadableStream<string> {
  const text = demoReply(history);
  const chunks = text.split(/(?<=[ \n])/);
  let i = 0;
  let closed = false;
  let timer: ReturnType<typeof setTimeout> | undefined;

  return new ReadableStream<string>({
    pull(controller) {
      if (closed) return;
      return new Promise<void>((resolve) => {
        timer = setTimeout(() => {
          if (i < chunks.length) {
            controller.enqueue(chunks[i++]);
          } else {
            closed = true;
            controller.close();
          }
          resolve();
        }, 18);
      });
    },
    cancel() {
      closed = true;
      if (timer) clearTimeout(timer);
    },
  });
}
