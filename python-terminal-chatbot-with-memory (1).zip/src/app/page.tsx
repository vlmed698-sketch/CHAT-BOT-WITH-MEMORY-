import ChatApp from "@/components/ChatApp";
import { aiConfig } from "@/lib/ai";

export const dynamic = "force-dynamic";

export default function Page() {
  const config = aiConfig();
  return (
    <ChatApp
      config={{
        configured: config.configured,
        provider: config.provider,
        model: config.model,
      }}
    />
  );
}
